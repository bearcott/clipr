backend for clipr that handles es thumbnails and models
