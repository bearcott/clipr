Handles Thumbnails from images
